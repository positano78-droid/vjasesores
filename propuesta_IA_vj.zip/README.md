
  # propuesta_IA_vj

  This is a code bundle for propuesta_IA_vj. The original project is available at https://www.figma.com/design/TDnPONiUOnqXocOSg8OBRb/propuesta_IA_vj.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  