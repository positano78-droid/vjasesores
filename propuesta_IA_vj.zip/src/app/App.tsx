import { useState, useEffect } from "react";
import { Check } from "lucide-react";
import logo from "figma:asset/b921d1ee62361ea407a02e579352e0957d12651a.png";
import problemaImage from "figma:asset/ca6166bb93480946cc1ecca6c4bc2733905bb68d.png";

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [flowStep, setFlowStep] = useState(0);

  // Navegación por teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Solo permitir navegación en slide 3 si estamos en el menú principal (flowStep === 0)
      if (currentSlide === 2 && flowStep !== 0) return;

      if (e.key === "ArrowLeft" && currentSlide > 0) {
        setCurrentSlide(currentSlide - 1);
        setFlowStep(0);
      } else if (e.key === "ArrowRight" && currentSlide < 6) {
        setCurrentSlide(currentSlide + 1);
        setFlowStep(0);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () =>
      window.removeEventListener("keydown", handleKeyDown);
  }, [currentSlide, flowStep]);

  // Navegación táctil (swipe)
  useEffect(() => {
    let touchStartX = 0;
    let touchEndX = 0;

    const handleTouchStart = (e: TouchEvent) => {
      // No permitir swipe en slide 3 si estamos dentro del flujo
      if (currentSlide === 2 && flowStep !== 0) return;
      touchStartX = e.changedTouches[0].screenX;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      // No permitir swipe en slide 3 si estamos dentro del flujo
      if (currentSlide === 2 && flowStep !== 0) return;

      touchEndX = e.changedTouches[0].screenX;
      handleSwipe();
    };

    const handleSwipe = () => {
      const swipeThreshold = 50; // Mínimo de píxeles para considerar un swipe

      if (touchStartX - touchEndX > swipeThreshold) {
        // Swipe izquierda (siguiente slide)
        if (currentSlide < 6) {
          setCurrentSlide(currentSlide + 1);
          setFlowStep(0);
        }
      }

      if (touchEndX - touchStartX > swipeThreshold) {
        // Swipe derecha (slide anterior)
        if (currentSlide > 0) {
          setCurrentSlide(currentSlide - 1);
          setFlowStep(0);
        }
      }
    };

    window.addEventListener("touchstart", handleTouchStart);
    window.addEventListener("touchend", handleTouchEnd);

    return () => {
      window.removeEventListener(
        "touchstart",
        handleTouchStart,
      );
      window.removeEventListener("touchend", handleTouchEnd);
    };
  }, [currentSlide, flowStep]);

  const slides = [
    // Slide 1 - Portada
    <div
      key="slide1"
      className="size-full bg-slate-900 flex flex-col items-center justify-center px-6 md:px-12 py-12 md:py-24"
    >
      <div className="mb-6 md:mb-12">
        <img
          src={logo}
          alt="Whanga Media"
          className="w-32 h-32 md:w-48 md:h-48 object-contain"
        />
      </div>
      <h1
        className="text-[48px] md:text-[64px] font-bold text-white mb-4 md:mb-8 text-center leading-tight"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        Whanga Media
      </h1>
      <p
        className="text-[24px] md:text-[32px] text-[#cbd5e1] text-center max-w-4xl leading-tight"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        Agencia de soluciones digitales
      </p>
    </div>,

    // Slide 2 - Problemas actuales
    <div
      key="slide2"
      className="size-full bg-slate-900 flex flex-col items-center justify-center px-6 md:px-12 py-6 md:py-8"
    >
      <h2
        className="text-[28px] md:text-[40px] font-bold text-[#f1f5f9] mb-4 md:mb-8 text-center leading-tight"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        Tu atención online hoy
      </h2>
      <div className="flex flex-col gap-3 md:gap-4 max-w-4xl w-full">
        {/* Caja 1 - Confusión Estratégica */}
        <div className="bg-[#1e293b] border-2 border-[#38bdf8] rounded-lg p-4 md:p-6 shadow-xl">
          <h3
            className="text-[20px] md:text-[24px] font-bold text-[#38bdf8] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Confusión Estratégica
          </h3>
          <p
            className="text-[14px] md:text-[16px] text-[#cbd5e1] leading-relaxed"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            El cliente no es experto. Decidir entre
            colorimetría, visajismo o morfología sin ayuda crea
            abandono.
          </p>
        </div>

        {/* Caja 2 - Falta de Cierre */}
        <div className="bg-[#1e293b] border-2 border-[#38bdf8] rounded-lg p-4 md:p-6 shadow-xl">
          <h3
            className="text-[20px] md:text-[24px] font-bold text-[#38bdf8] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Falta de Cierre
          </h3>
          <p
            className="text-[14px] md:text-[16px] text-[#cbd5e1] leading-relaxed"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            La web informa, pero no vende. No hay nadie
            empujando al visitante hacia la compra o reserva.
          </p>
        </div>

        {/* Caja 3 - Formularios Estáticos */}
        <div className="bg-[#1e293b] border-2 border-[#38bdf8] rounded-lg p-4 md:p-6 shadow-xl">
          <h3
            className="text-[20px] md:text-[24px] font-bold text-[#38bdf8] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Formularios Estáticos
          </h3>
          <p
            className="text-[14px] md:text-[16px] text-[#cbd5e1] leading-relaxed"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Los formularios tradicionales son un proceso lento y
            burocrático para un servicio ágil.
          </p>
        </div>

        {/* Caja 4 - Sin filtro */}
        <div className="bg-[#1e293b] border-2 border-[#38bdf8] rounded-lg p-4 md:p-6 shadow-xl">
          <h3
            className="text-[20px] md:text-[24px] font-bold text-[#38bdf8] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Sin filtro
          </h3>
          <p
            className="text-[14px] md:text-[16px] text-[#cbd5e1] leading-relaxed"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            No hay un sistema de cualificación de leads.
          </p>
        </div>
      </div>
    </div>,

    // Slide 3 - Flujo visual interactivo
    <div
      key="slide3"
      className="size-full bg-slate-900 flex flex-col items-center justify-start px-6 md:px-12 py-4 md:py-8 overflow-auto"
    >
      {flowStep === 0 && (
        <>
          <div className="text-center mb-4 md:mb-8">
            <h2
              className="text-[36px] md:text-[48px] font-bold text-[#f1f5f9] mb-2 md:mb-4 leading-tight"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              Te proponemos un agente de atención con IA
            </h2>
            <div className="bg-[#38bdf8] inline-block px-6 py-3 md:px-8 md:py-4 rounded-lg shadow-lg">
              <p
                className="text-[18px] md:text-[28px] text-white font-bold"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                👇 Haz clic en cualquier paso para ver cómo
                funciona
              </p>
            </div>
          </div>

          {/* Contenedor maestro con Auto Layout Wrap - Padding 24px, Gap horizontal 20px, vertical 24px */}
          <div className="flex flex-wrap justify-center items-center gap-x-5 gap-y-6 max-w-5xl px-6">
            {/* Paso 1 */}
            <div
              onClick={() => setFlowStep(1)}
              className="bg-[#1e293b] rounded-lg p-5 md:p-6 flex flex-col items-center text-center cursor-pointer hover:bg-[#2d3f59] transition-colors min-w-[140px] md:w-[180px] border-2 border-[#38bdf8]"
            >
              <div className="w-8 h-8 md:w-10 md:h-10 bg-[#38bdf8] rounded-full flex items-center justify-center text-white font-bold text-base md:text-xl mb-2 md:mb-3">
                1
              </div>
              <h3
                className="text-[12px] md:text-[16px] font-bold text-[#f1f5f9] mb-1 md:mb-2"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                SALUDO
              </h3>
              <p
                className="text-[10px] md:text-[14px] text-[#cbd5e1] opacity-70"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Bienvenida
              </p>
            </div>

            {/* Flecha → (solo visible en desktop) */}
            <div className="hidden md:block text-[#38bdf8] text-[24px]">
              →
            </div>

            {/* Paso 2 */}
            <div
              onClick={() => setFlowStep(2)}
              className="bg-[#1e293b] rounded-lg p-5 md:p-6 flex flex-col items-center text-center cursor-pointer hover:bg-[#2d3f59] transition-colors min-w-[140px] md:w-[180px] border-2 border-[#38bdf8]"
            >
              <div className="w-8 h-8 md:w-10 md:h-10 bg-[#38bdf8] rounded-full flex items-center justify-center text-white font-bold text-base md:text-xl mb-2 md:mb-3">
                2
              </div>
              <h3
                className="text-[12px] md:text-[16px] font-bold text-[#f1f5f9] mb-1 md:mb-2"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                NECESIDAD
              </h3>
              <p
                className="text-[10px] md:text-[14px] text-[#cbd5e1] opacity-70"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Qué busca
              </p>
            </div>

            {/* Flecha → (solo visible en desktop) */}
            <div className="hidden md:block text-[#38bdf8] text-[24px]">
              →
            </div>

            {/* Paso 3 */}
            <div
              onClick={() => setFlowStep(3)}
              className="bg-[#1e293b] rounded-lg p-5 md:p-6 flex flex-col items-center text-center cursor-pointer hover:bg-[#2d3f59] transition-colors min-w-[140px] md:w-[180px] border-2 border-[#38bdf8]"
            >
              <div className="w-8 h-8 md:w-10 md:h-10 bg-[#38bdf8] rounded-full flex items-center justify-center text-white font-bold text-base md:text-xl mb-2 md:mb-3">
                3
              </div>
              <h3
                className="text-[12px] md:text-[16px] font-bold text-[#f1f5f9] mb-1 md:mb-2"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                RECOMENDACIÓN
              </h3>
              <p
                className="text-[10px] md:text-[14px] text-[#cbd5e1] opacity-70"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Asesora
              </p>
            </div>

            {/* Flecha → (solo visible en desktop) */}
            <div className="hidden md:block text-[#38bdf8] text-[24px]">
              →
            </div>

            {/* Paso 4 */}
            <div
              onClick={() => setFlowStep(4)}
              className="bg-[#1e293b] rounded-lg p-5 md:p-6 flex flex-col items-center text-center cursor-pointer hover:bg-[#2d3f59] transition-colors min-w-[140px] md:w-[180px] border-2 border-[#38bdf8]"
            >
              <div className="w-8 h-8 md:w-10 md:h-10 bg-[#38bdf8] rounded-full flex items-center justify-center text-white font-bold text-base md:text-xl mb-2 md:mb-3">
                4
              </div>
              <h3
                className="text-[12px] md:text-[16px] font-bold text-[#f1f5f9] mb-1 md:mb-2"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                DISPONIBILIDAD
              </h3>
              <p
                className="text-[10px] md:text-[14px] text-[#cbd5e1] opacity-70"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Horarios
              </p>
            </div>

            {/* Flecha → (solo visible en desktop) */}
            <div className="hidden md:block text-[#38bdf8] text-[24px]">
              →
            </div>

            {/* Paso 5 */}
            <div
              onClick={() => setFlowStep(5)}
              className="bg-[#1e293b] rounded-lg p-5 md:p-6 flex flex-col items-center text-center cursor-pointer hover:bg-[#2d3f59] transition-colors min-w-[140px] md:w-[180px] border-2 border-[#38bdf8]"
            >
              <div className="w-8 h-8 md:w-10 md:h-10 bg-[#38bdf8] rounded-full flex items-center justify-center text-white font-bold text-base md:text-xl mb-2 md:mb-3">
                5
              </div>
              <h3
                className="text-[12px] md:text-[16px] font-bold text-[#f1f5f9] mb-1 md:mb-2"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                CONFIRMADA
              </h3>
              <p
                className="text-[10px] md:text-[14px] text-[#cbd5e1] opacity-70"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Sesión
              </p>
            </div>
          </div>
        </>
      )}

      {/* Paso 1 - Saludo inicial */}
      {flowStep === 1 && (
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-2xl flex h-[500px] md:h-[600px] flex-col">
          {/* A) Header */}
          <div className="flex-shrink-0 flex items-center gap-2 md:gap-3 bg-[#075e54] text-white px-3 md:px-6 py-2 md:py-4">
            <div className="w-8 h-8 md:w-12 md:h-12 bg-gradient-to-br from-[#38bdf8] to-[#0ea5e9] rounded-full flex items-center justify-center text-white text-sm md:text-xl font-bold">
              🤖
            </div>
            <div className="flex-1">
              <h3
                className="font-bold text-white flex items-center gap-1 md:gap-2 text-[10px] md:text-base"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Asistente IA - Imagen & Personal Shopping
                <span className="bg-[#38bdf8] text-white text-[8px] md:text-xs px-1 md:px-2 py-0.5 md:py-1 rounded-full">
                  BOT
                </span>
              </h3>
              <p
                className="text-[8px] md:text-sm text-gray-200"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Respuesta automática 24/7
              </p>
            </div>
          </div>

          {/* B) ChatArea (scroll) */}
          <div className="min-h-0 flex-1 overflow-y-auto pb-12 md:pb-24 p-3 md:p-6 bg-[#e5ddd5] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden space-y-2 md:space-y-4">
            <div className="flex justify-end">
              <div className="bg-[#dcf8c6] rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  Hola! 👋
                </p>
              </div>
            </div>
            <div className="flex justify-start">
              <div className="bg-white rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <div className="flex items-center gap-1 md:gap-2 mb-1">
                  <span className="text-[8px] md:text-xs bg-[#38bdf8] text-white px-1 md:px-2 py-0.5 rounded-full font-bold">
                    🤖 BOT
                  </span>
                </div>
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  ¡Hola! 😊 Soy tu asistente de imagen personal.
                  Estoy aquí para ayudarte a descubrir tu mejor
                  versión. ¿En qué puedo ayudarte hoy?
                </p>
              </div>
            </div>
          </div>

          {/* C) Footer fijo */}
          <div className="absolute bottom-3 md:bottom-6 left-3 md:left-6 right-3 md:right-6 flex gap-2">
            <button
              onClick={() => setFlowStep(2)}
              className="flex-1 bg-[#38bdf8] text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-[#0ea5e9] transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              Siguiente →
            </button>
          </div>
        </div>
      )}

      {/* Paso 2 - Identifica necesidad */}
      {flowStep === 2 && (
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-2xl flex h-[500px] md:h-[600px] flex-col">
          <div className="flex-shrink-0 flex items-center gap-2 md:gap-3 bg-[#075e54] text-white px-3 md:px-6 py-2 md:py-4">
            <div className="w-8 h-8 md:w-12 md:h-12 bg-gradient-to-br from-[#38bdf8] to-[#0ea5e9] rounded-full flex items-center justify-center text-white text-sm md:text-xl font-bold">
              🤖
            </div>
            <div className="flex-1">
              <h3
                className="font-bold text-white flex items-center gap-1 md:gap-2 text-[10px] md:text-base"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Asistente IA - Imagen & Personal Shopping
                <span className="bg-[#38bdf8] text-white text-[8px] md:text-xs px-1 md:px-2 py-0.5 md:py-1 rounded-full">
                  BOT
                </span>
              </h3>
              <p
                className="text-[8px] md:text-sm text-gray-200"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Respuesta automática 24/7
              </p>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto pb-12 md:pb-24 p-3 md:p-6 bg-[#e5ddd5] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden space-y-2 md:space-y-4">
            <div className="flex justify-end">
              <div className="bg-[#dcf8c6] rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  No sé muy bien qué necesito... me gustaría
                  renovar mi imagen
                </p>
              </div>
            </div>
            <div className="flex justify-start">
              <div className="bg-white rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <div className="flex items-center gap-1 md:gap-2 mb-1">
                  <span className="text-[8px] md:text-xs bg-[#38bdf8] text-white px-1 md:px-2 py-0.5 rounded-full font-bold">
                    🤖 BOT
                  </span>
                </div>
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  ¡Perfecto! Te ayudo a identificar qué
                  necesitas. Dime, ¿cuál de estas situaciones te
                  describe mejor?
                  <br />
                  <br />
                  1️⃣ No sé qué colores me favorecen
                  <br />
                  2️⃣ Quiero renovar mi guardarropa
                  <br />
                  3️⃣ Necesito un cambio completo de look
                  <br />
                  4️⃣ Tengo un evento especial próximo
                </p>
              </div>
            </div>
          </div>

          <div className="absolute bottom-3 md:bottom-6 left-3 md:left-6 right-3 md:right-6 flex gap-2">
            <button
              onClick={() => setFlowStep(1)}
              className="flex-1 bg-gray-500 text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-gray-600 transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              ← Atrás
            </button>
            <button
              onClick={() => setFlowStep(3)}
              className="flex-1 bg-[#38bdf8] text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-[#0ea5e9] transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              Siguiente →
            </button>
          </div>
        </div>
      )}

      {/* Paso 3 - Recomendación personalizada */}
      {flowStep === 3 && (
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-2xl flex h-[500px] md:h-[600px] flex-col">
          <div className="flex-shrink-0 flex items-center gap-2 md:gap-3 bg-[#075e54] text-white px-3 md:px-6 py-2 md:py-4">
            <div className="w-8 h-8 md:w-12 md:h-12 bg-gradient-to-br from-[#38bdf8] to-[#0ea5e9] rounded-full flex items-center justify-center text-white text-sm md:text-xl font-bold">
              🤖
            </div>
            <div className="flex-1">
              <h3
                className="font-bold text-white flex items-center gap-1 md:gap-2 text-[10px] md:text-base"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Asistente IA - Imagen & Personal Shopping
                <span className="bg-[#38bdf8] text-white text-[8px] md:text-xs px-1 md:px-2 py-0.5 md:py-1 rounded-full">
                  BOT
                </span>
              </h3>
              <p
                className="text-[8px] md:text-sm text-gray-200"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Respuesta automática 24/7
              </p>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto pb-12 md:pb-24 p-3 md:p-6 bg-[#e5ddd5] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden space-y-2 md:space-y-4">
            <div className="flex justify-end">
              <div className="bg-[#dcf8c6] rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  La opción 3, necesito un cambio completo
                </p>
              </div>
            </div>
            <div className="flex justify-start">
              <div className="bg-white rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <div className="flex items-center gap-1 md:gap-2 mb-1">
                  <span className="text-[8px] md:text-xs bg-[#38bdf8] text-white px-1 md:px-2 py-0.5 rounded-full font-bold">
                    🤖 BOT
                  </span>
                </div>
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  ¡Excelente elección! 🎨 Para un cambio
                  completo te recomiendo nuestro Pack
                  Transformación que incluye:
                  <br />
                  <br />
                  ✨ Colorimetría personal
                  <br />
                  💄 Visajismo
                  <br />
                  👗 Morfología corporal
                  <br />
                  🛍️ Personal shopping online
                  <br />
                  <br />
                  Precio: 180€ | Sesión online 90 min
                  <br />
                  <br />
                  ¿Te gustaría reservar una sesión?
                </p>
              </div>
            </div>
          </div>

          <div className="absolute bottom-3 md:bottom-6 left-3 md:left-6 right-3 md:right-6 flex gap-2">
            <button
              onClick={() => setFlowStep(2)}
              className="flex-1 bg-gray-500 text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-gray-600 transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              ← Atrás
            </button>
            <button
              onClick={() => setFlowStep(4)}
              className="flex-1 bg-[#38bdf8] text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-[#0ea5e9] transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              Siguiente →
            </button>
          </div>
        </div>
      )}

      {/* Paso 4 - Disponibilidad */}
      {flowStep === 4 && (
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-2xl flex h-[500px] md:h-[600px] flex-col">
          <div className="flex-shrink-0 flex items-center gap-2 md:gap-3 bg-[#075e54] text-white px-3 md:px-6 py-2 md:py-4">
            <div className="w-8 h-8 md:w-12 md:h-12 bg-gradient-to-br from-[#38bdf8] to-[#0ea5e9] rounded-full flex items-center justify-center text-white text-sm md:text-xl font-bold">
              🤖
            </div>
            <div className="flex-1">
              <h3
                className="font-bold text-white flex items-center gap-1 md:gap-2 text-[10px] md:text-base"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Asistente IA - Imagen & Personal Shopping
                <span className="bg-[#38bdf8] text-white text-[8px] md:text-xs px-1 md:px-2 py-0.5 md:py-1 rounded-full">
                  BOT
                </span>
              </h3>
              <p
                className="text-[8px] md:text-sm text-gray-200"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Respuesta automática 24/7
              </p>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto pb-12 md:pb-24 p-3 md:p-6 bg-[#e5ddd5] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden space-y-2 md:space-y-4">
            <div className="flex justify-end">
              <div className="bg-[#dcf8c6] rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  Sí, me interesa! ¿Qué días tenéis disponibles?
                </p>
              </div>
            </div>
            <div className="flex justify-start">
              <div className="bg-white rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <div className="flex items-center gap-1 md:gap-2 mb-1">
                  <span className="text-[8px] md:text-xs bg-[#38bdf8] text-white px-1 md:px-2 py-0.5 rounded-full font-bold">
                    🤖 BOT
                  </span>
                </div>
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  ¡Genial! 🎉 Tengo disponibilidad esta semana:
                  <br />
                  <br />
                  📅 <strong>Miércoles 12 febrero</strong>
                  <br />
                  ⏰ 10:00 - 17:00 - 19:30
                  <br />
                  <br />
                  📅 <strong>Viernes 14 febrero</strong>
                  <br />
                  ⏰ 11:00 - 16:00 - 18:30
                  <br />
                  <br />
                  📅 <strong>Sábado 15 febrero</strong>
                  <br />
                  ⏰ 10:30 - 12:00
                  <br />
                  <br />
                  ¿Qué día y hora prefieres?
                </p>
              </div>
            </div>
          </div>

          <div className="absolute bottom-3 md:bottom-6 left-3 md:left-6 right-3 md:right-6 flex gap-2">
            <button
              onClick={() => setFlowStep(3)}
              className="flex-1 bg-gray-500 text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-gray-600 transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              ← Atrás
            </button>
            <button
              onClick={() => setFlowStep(5)}
              className="flex-1 bg-[#38bdf8] text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-[#0ea5e9] transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              Siguiente →
            </button>
          </div>
        </div>
      )}

      {/* Paso 5 - Sesión confirmada */}
      {flowStep === 5 && (
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-2xl flex h-[500px] md:h-[600px] flex-col">
          <div className="flex-shrink-0 flex items-center gap-2 md:gap-3 bg-[#075e54] text-white px-3 md:px-6 py-2 md:py-4">
            <div className="w-8 h-8 md:w-12 md:h-12 bg-gradient-to-br from-[#38bdf8] to-[#0ea5e9] rounded-full flex items-center justify-center text-white text-sm md:text-xl font-bold">
              🤖
            </div>
            <div className="flex-1">
              <h3
                className="font-bold text-white flex items-center gap-1 md:gap-2 text-[10px] md:text-base"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Asistente IA - Imagen & Personal Shopping
                <span className="bg-[#38bdf8] text-white text-[8px] md:text-xs px-1 md:px-2 py-0.5 md:py-1 rounded-full">
                  BOT
                </span>
              </h3>
              <p
                className="text-[8px] md:text-sm text-gray-200"
                style={{ fontFamily: "Arial, sans-serif" }}
              >
                Respuesta automática 24/7
              </p>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto pb-12 md:pb-24 p-3 md:p-6 bg-[#e5ddd5] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden space-y-2 md:space-y-4">
            <div className="flex justify-end">
              <div className="bg-[#dcf8c6] rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  El viernes 14 a las 16:00 me viene perfecto
                </p>
              </div>
            </div>
            <div className="flex justify-start">
              <div className="bg-white rounded-lg p-2 md:p-4 max-w-[200px] md:max-w-sm shadow">
                <div className="flex items-center gap-1 md:gap-2 mb-1">
                  <span className="text-[8px] md:text-xs bg-[#38bdf8] text-white px-1 md:px-2 py-0.5 rounded-full font-bold">
                    🤖 BOT
                  </span>
                </div>
                <p
                  className="text-gray-900 text-[10px] md:text-base"
                  style={{ fontFamily: "Arial, sans-serif" }}
                >
                  ✅ ¡Sesión reservada con éxito!
                  <br />
                  <br />
                  📅 Viernes 14 de febrero
                  <br />
                  🕐 16:00h (90 minutos)
                  <br />
                  💻 Sesión online vía Zoom
                  <br />
                  🎨 Pack Transformación Completo
                  <br />
                  💰 180€
                  <br />
                  <br />
                  Te enviaré por email:
                  <br />
                  📧 Link de Zoom
                  <br />
                  📋 Cuestionario previo
                  <br />
                  💳 Datos de pago
                  <br />
                  <br />
                  ¡Nos vemos pronto! 😊✨
                </p>
              </div>
            </div>
          </div>

          <div className="absolute bottom-3 md:bottom-6 left-3 md:left-6 right-3 md:right-6 flex gap-2">
            <button
              onClick={() => setFlowStep(4)}
              className="flex-1 bg-gray-500 text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-gray-600 transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              ← Atrás
            </button>
            <button
              onClick={() => setFlowStep(0)}
              className="flex-1 bg-[#38bdf8] text-white py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-[#0ea5e9] transition-colors text-[10px] md:text-base font-semibold"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              ← Menú
            </button>
          </div>
        </div>
      )}
    </div>,

    // Slide 4 - Impacto económico
    <div
      key="slide4"
      className="size-full bg-slate-900 flex flex-col items-center justify-center px-6 md:px-12 py-8 md:py-12"
    >
      <h2
        className="text-[32px] md:text-[48px] font-bold text-[#f1f5f9] mb-6 md:mb-12 text-center leading-tight"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        Impacto económico real
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12 max-w-5xl w-full">
        <div className="bg-[#1e293b] rounded-lg p-6 md:p-8 border-2 border-[#38bdf8]">
          <h3
            className="text-[24px] md:text-[32px] font-bold text-[#38bdf8] mb-4"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Sin agente IA
          </h3>
          <p
            className="text-[16px] md:text-[20px] text-[#cbd5e1] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            📉 Clientes indecisos que abandonan sin reservar
          </p>
          <p
            className="text-[16px] md:text-[20px] text-[#cbd5e1] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            ⏰ Consultas no cualificadas consumen tiempo
          </p>
          <p
            className="text-[16px] md:text-[20px] text-[#cbd5e1]"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            💸 Pérdida de leads fuera de horario
          </p>
        </div>
        <div className="bg-[#1e293b] rounded-lg p-6 md:p-8 border-2 border-[#38bdf8]">
          <h3
            className="text-[24px] md:text-[32px] font-bold text-[#38bdf8] mb-4"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            Con agente IA
          </h3>
          <p
            className="text-[16px] md:text-[20px] text-[#cbd5e1] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            📉 Guía al cliente hacia la reserva automáticamente
          </p>
          <p
            className="text-[16px] md:text-[20px] text-[#cbd5e1] mb-2"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            🎯 Cualifica leads 24/7 sin intervención
          </p>
          <p
            className="text-[16px] md:text-[20px] text-[#cbd5e1]"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            💰 +40% conversión: 12 sesiones/mes extra
          </p>
        </div>
      </div>
    </div>,

    // Slide 5 - Antes vs Después
    <div
      key="slide5"
      className="size-full bg-slate-900 flex flex-col items-center justify-center px-6 md:px-12 py-8 md:py-12"
    >
      <h2
        className="text-[32px] md:text-[48px] font-bold text-[#f1f5f9] mb-6 md:mb-12 text-center leading-tight"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        Antes vs Después
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12 max-w-5xl w-full">
        <div className="bg-[#1e293b] rounded-lg p-6 md:p-8 border-2 border-[#38bdf8]">
          <h3
            className="text-[24px] md:text-[32px] font-bold text-[#f1f5f9] mb-4"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            ❌ Antes
          </h3>
          <ul className="space-y-3">
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <span>•</span>
              <span>
                Visitantes confundidos entre servicios sin guía
              </span>
            </li>
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <span>•</span>
              <span>Formularios que nadie completa</span>
            </li>
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <span>•</span>
              <span>
                Leads sin cualificar que no convierten
              </span>
            </li>
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <span>•</span>
              <span>
                Tráfico web que no se transforma en reservas
              </span>
            </li>
          </ul>
        </div>
        <div className="bg-[#1e293b] rounded-lg p-6 md:p-8 border-2 border-[#38bdf8]">
          <h3
            className="text-[24px] md:text-[32px] font-bold text-[#38bdf8] mb-4"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            ✅ Después
          </h3>
          <ul className="space-y-3">
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <Check className="w-5 h-5 text-[#38bdf8] flex-shrink-0" />
              <span>
                Bot guía al cliente hacia el servicio ideal
              </span>
            </li>
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <Check className="w-5 h-5 text-[#38bdf8] flex-shrink-0" />
              <span>
                Conversación natural que cierra ventas
              </span>
            </li>
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <Check className="w-5 h-5 text-[#38bdf8] flex-shrink-0" />
              <span>
                Sistema automático de cualificación 24/7
              </span>
            </li>
            <li
              className="text-[16px] md:text-[18px] text-[#cbd5e1] flex items-start gap-2"
              style={{ fontFamily: "Arial, sans-serif" }}
            >
              <Check className="w-5 h-5 text-[#38bdf8] flex-shrink-0" />
              <span>Servicio online premium</span>
            </li>
          </ul>
        </div>
      </div>
    </div>,

    // Slide 6 - CTA Final
    <div
      key="slide6"
      className="size-full bg-slate-900 flex flex-col items-center justify-center px-6 md:px-12 py-12 md:py-24"
    >
      <h2
        className="text-[40px] md:text-[56px] font-bold text-[#f1f5f9] mb-6 md:mb-12 text-center leading-tight"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        ¿Listo para transformar tu soporte online?
      </h2>
      <p
        className="text-[20px] md:text-[28px] text-[#cbd5e1] text-center max-w-3xl mb-8 md:mb-16"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        Agenda una demo gratuita (20 mnts) y descubre cómo
        nuestro agente IA puede aumentar tus ingresos
      </p>
      <a
        href="https://cal.com/oscar1978/30min"
        target="_blank"
        rel="noopener noreferrer"
        className="bg-[#38bdf8] text-white text-[20px] md:text-[28px] px-8 md:px-16 py-4 md:py-6 rounded-full hover:bg-[#0ea5e9] transition-colors font-bold shadow-2xl inline-flex items-center justify-center gap-2"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        <span>🚀</span>
        <span>Agenda tu demo aquí</span>
      </a>
    </div>,
  ];

  return (
    <div className="relative size-full bg-slate-900 overflow-hidden">
      {slides[currentSlide]}

      {/* Indicadores de slides */}
      <div className="absolute bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 flex gap-2 md:gap-3 z-50">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setCurrentSlide(index);
              setFlowStep(0);
            }}
            className={`w-2 h-2 md:w-3 md:h-3 rounded-full transition-all ${
              currentSlide === index
                ? "bg-[#38bdf8] w-6 md:w-8"
                : "bg-gray-500 hover:bg-gray-400"
            }`}
            aria-label={`Ir a slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Navegación por flechas (solo desktop) */}
      <div className="hidden md:flex absolute inset-y-0 left-0 right-0 pointer-events-none">
        {currentSlide > 0 && (
          <button
            onClick={() => {
              setCurrentSlide(currentSlide - 1);
              setFlowStep(0);
            }}
            className="pointer-events-auto absolute left-4 md:left-8 top-1/2 -translate-y-1/2 bg-[#38bdf8] text-white p-3 md:p-4 rounded-full hover:bg-[#0ea5e9] transition-colors"
            aria-label="Slide anterior"
          >
            <svg
              className="w-5 h-5 md:w-6 md:h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
          </button>
        )}
        {currentSlide < slides.length - 1 && (
          <button
            onClick={() => {
              setCurrentSlide(currentSlide + 1);
              setFlowStep(0);
            }}
            className="pointer-events-auto absolute right-4 md:right-8 top-1/2 -translate-y-1/2 bg-[#38bdf8] text-white p-3 md:p-4 rounded-full hover:bg-[#0ea5e9] transition-colors"
            aria-label="Siguiente slide"
          >
            <svg
              className="w-5 h-5 md:w-6 md:h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </button>
        )}
      </div>
    </div>
  );
}